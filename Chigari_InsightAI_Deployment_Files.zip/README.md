# Chigari InsightAI

**Turn Data Into Clear Insights**

A Gradio app for exploring CSV and Excel datasets. It checks missing values and duplicate rows, summarizes numeric columns, previews the first 20 rows, and creates simple charts.

## Deploy on Render

1. Put `app.py` and `requirements.txt` in the root of your GitHub repository.
2. In Render, create a new **Web Service** and connect your GitHub repository.
3. Choose the Free instance type if available.
4. Build command: `pip install -r requirements.txt`
5. Start command: `python app.py`
6. Create the service and wait for the build to finish.

Free services may sleep after inactivity and may take a little time to wake up. Check Render's current plan details before deploying.

## Privacy

Uploaded files are processed by the running app. Do not upload confidential, sensitive, or personally identifying data. This starter app does not intentionally save uploaded datasets.
